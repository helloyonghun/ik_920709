package com.ds.vo;

public class ItemALL {
	private int item_no = 0;
	private String item_name = null;
	private String item_content = null;
	private int item_price = 0;
	private String item_img1 = "default.png";
	private String item_img2 = "default.png";
	private String item_img3 = "default.png";

	public int getItem_no() {
		return item_no;
	}

	public void setItem_no(int item_no) {
		this.item_no = item_no;
	}

	public String getItem_name() {
		return item_name;
	}

	public void setItem_name(String item_name) {
		this.item_name = item_name;
	}

	public String getItem_content() {
		return item_content;
	}

	public void setItem_content(String item_content) {
		this.item_content = item_content;
	}

	public int getItem_price() {
		return item_price;
	}

	public void setItem_price(int item_price) {
		this.item_price = item_price;
	}

	public String getItem_img1() {
		return item_img1;
	}

	public void setItem_img1(String item_img1) {
		this.item_img1 = item_img1;
	}

	public String getItem_img2() {
		return item_img2;
	}

	public void setItem_img2(String item_img2) {
		this.item_img2 = item_img2;
	}

	public String getItem_img3() {
		return item_img3;
	}

	public void setItem_img3(String item_img3) {
		this.item_img3 = item_img3;
	}

}
