package com.ds.vo;

public class ItemCartVO {
	private int item_no = 0;
	private int cart_no = 0;
	private String item_img1 = null;
	private String item_name = null;
	private int item_price = 0;
	private String item_size = null;
	private int cart_cnt = 0;
	private String mem_id = null;
	private int item_sumprice = 0;

	
	public String getItem_size() {
		return item_size;
	}

	public void setItem_size(String item_size) {
		this.item_size = item_size;
	}

	public int getCart_no() {
		return cart_no;
	}

	public void setCart_no(int cart_no) {
		this.cart_no = cart_no;
	}

	public int getItem_no() {
		return item_no;
	}

	public void setItem_no(int item_no) {
		this.item_no = item_no;
	}

	public int getItem_sumprice() {
		return item_sumprice;
	}

	public void setItem_sumprice(int item_sumprice) {
		this.item_sumprice = item_sumprice;
	}

	public String getItem_img1() {
		return item_img1;
	}

	public void setItem_img1(String item_img1) {
		this.item_img1 = item_img1;
	}

	public String getItem_name() {
		return item_name;
	}

	public void setItem_name(String item_name) {
		this.item_name = item_name;
	}

	public int getItem_price() {
		return item_price;
	}

	public void setItem_price(int item_price) {
		this.item_price = item_price;
	}

	public int getCart_cnt() {
		return cart_cnt;
	}

	public void setCart_cnt(int cart_cnt) {
		this.cart_cnt = cart_cnt;
	}

	public String getMem_id() {
		return mem_id;
	}

	public void setMem_id(String mem_id) {
		this.mem_id = mem_id;
	}

}
