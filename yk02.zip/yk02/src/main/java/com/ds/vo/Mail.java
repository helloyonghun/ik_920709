package com.ds.vo;

public class Mail {
	private int mail_no = 0;
	private String mem_id = null;
	private String mem_name = null;
	private String mail_title = null;
	private String content = null;
	private String mail_date = null;
	private int mail_answer = 0;

	public int getMail_answer() {
		return mail_answer;
	}

	public void setMail_answer(int mail_answer) {
		this.mail_answer = mail_answer;
	}

	public String getMail_date() {
		return mail_date;
	}

	public void setMail_date(String mail_date) {
		this.mail_date = mail_date;
	}

	public int getMail_no() {
		return mail_no;
	}

	public void setMail_no(int mail_no) {
		this.mail_no = mail_no;
	}

	public String getMem_id() {
		return mem_id;
	}

	public void setMem_id(String mem_id) {
		this.mem_id = mem_id;
	}

	public String getMem_name() {
		return mem_name;
	}

	public void setMem_name(String mem_name) {
		this.mem_name = mem_name;
	}

	public String getMail_title() {
		return mail_title;
	}

	public void setMail_title(String mail_title) {
		this.mail_title = mail_title;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

}
