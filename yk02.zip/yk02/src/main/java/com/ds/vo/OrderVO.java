package com.ds.vo;

public class OrderVO {
	private int order_no = 0;
	private int item_no = 0;
	private int item_price = 0;
	private String mem_id = null;
	private String order_payment = null;
	private String order_sign = null;
	private String item_size = null;
	private String order_coin = null;
	private String item_name = null;
	private int order_cnt = 0;
	private int item_size_count = 0;
	private String item_size_name = null;

	public String getItem_size_name() {
		return item_size_name;
	}
//cloth_size_qty
	public void setItem_size_name(String item_size_name) {
		this.item_size_name = item_size_name;
	}

	public int getItem_size_count() {
		return item_size_count;
	}

	public void setItem_size_count(int item_size_count) {
		this.item_size_count = item_size_count;
	}

	public String getItem_size() {
		return item_size;
	}

	public void setItem_size(String item_size) {
		this.item_size = item_size;
	}

	public String getItem_name() {
		return item_name;
	}

	public void setItem_name(String item_name) {
		this.item_name = item_name;
	}

	public int getOrder_cnt() {
		return order_cnt;
	}

	public void setOrder_cnt(int order_cnt) {
		this.order_cnt = order_cnt;
	}

	public String getOrder_coin() {
		return order_coin;
	}

	public void setOrder_coin(String order_coin) {
		this.order_coin = order_coin;
	}

	public int getOrder_no() {
		return order_no;
	}

	public void setOrder_no(int order_no) {
		this.order_no = order_no;
	}

	public int getItem_no() {
		return item_no;
	}

	public void setItem_no(int item_no) {
		this.item_no = item_no;
	}

	public int getItem_price() {
		return item_price;
	}

	public void setItem_price(int item_price) {
		this.item_price = item_price;
	}

	public String getMem_id() {
		return mem_id;
	}

	public void setMem_id(String mem_id) {
		this.mem_id = mem_id;
	}

	public String getOrder_payment() {
		return order_payment;
	}

	public void setOrder_payment(String order_payment) {
		this.order_payment = order_payment;
	}

	public String getOrder_sign() {
		return order_sign;
	}

	public void setOrder_sign(String order_sign) {
		this.order_sign = order_sign;
	}

}
