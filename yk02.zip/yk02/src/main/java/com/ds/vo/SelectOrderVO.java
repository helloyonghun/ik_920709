package com.ds.vo;

public class SelectOrderVO {
	private int order_no = 0;
	private String mem_id = null;
	private String mem_phone = null;
	private String item_name = null;
	private String mem_postnum = null;
	private String mem_addr1 = null;
	private String mem_addr2 = null;
	private String mem_name = null;
	private int item_no = 0;
	private int item_price = 0;
	private int order_cnt = 0;
	private String order_date = null;
	private String order_coin = null;
	private int item_sumprice = 0;

	
	public int getOrder_no() {
		return order_no;
	}

	public void setOrder_no(int order_no) {
		this.order_no = order_no;
	}

	public int getItem_sumprice() {
		return item_sumprice;
	}

	public void setItem_sumprice(int item_sumprice) {
		this.item_sumprice = item_sumprice;
	}

	public String getItem_name() {
		return item_name;
	}

	public void setItem_name(String item_name) {
		this.item_name = item_name;
	}

	public String getMem_id() {
		return mem_id;
	}

	public void setMem_id(String mem_id) {
		this.mem_id = mem_id;
	}

	public String getMem_phone() {
		return mem_phone;
	}

	public void setMem_phone(String mem_phone) {
		this.mem_phone = mem_phone;
	}

	public String getMem_postnum() {
		return mem_postnum;
	}

	public void setMem_postnum(String mem_postnum) {
		this.mem_postnum = mem_postnum;
	}

	public String getMem_addr1() {
		return mem_addr1;
	}

	public void setMem_addr1(String mem_addr1) {
		this.mem_addr1 = mem_addr1;
	}

	public String getMem_addr2() {
		return mem_addr2;
	}

	public void setMem_addr2(String mem_addr2) {
		this.mem_addr2 = mem_addr2;
	}

	public String getMem_name() {
		return mem_name;
	}

	public void setMem_name(String mem_name) {
		this.mem_name = mem_name;
	}

	public int getItem_no() {
		return item_no;
	}

	public void setItem_no(int item_no) {
		this.item_no = item_no;
	}

	public int getItem_price() {
		return item_price;
	}

	public void setItem_price(int item_price) {
		this.item_price = item_price;
	}

	public int getOrder_cnt() {
		return order_cnt;
	}

	public void setOrder_cnt(int order_cnt) {
		this.order_cnt = order_cnt;
	}

	public String getOrder_date() {
		return order_date;
	}

	public void setOrder_date(String order_date) {
		this.order_date = order_date;
	}

	public String getOrder_coin() {
		return order_coin;
	}

	public void setOrder_coin(String order_coin) {
		this.order_coin = order_coin;
	}

}
