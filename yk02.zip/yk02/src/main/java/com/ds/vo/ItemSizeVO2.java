package com.ds.vo;

public class ItemSizeVO2 {
	private int item_size_no = 0;
	private int item_no = 0;
	private int xs = 0;
	private int s = 0;
	private int m = 0;
	private int l = 0;
	private int xl = 0;
	private int xxl = 0;

	public int getItem_size_no() {
		return item_size_no;
	}

	public void setItem_size_no(int item_size_no) {
		this.item_size_no = item_size_no;
	}

	public int getItem_no() {
		return item_no;
	}

	public void setItem_no(int item_no) {
		this.item_no = item_no;
	}

	public int getXs() {
		return xs;
	}

	public void setXs(int xs) {
		this.xs = xs;
	}

	public int getS() {
		return s;
	}

	public void setS(int s) {
		this.s = s;
	}

	public int getM() {
		return m;
	}

	public void setM(int m) {
		this.m = m;
	}

	public int getL() {
		return l;
	}

	public void setL(int l) {
		this.l = l;
	}

	public int getXl() {
		return xl;
	}

	public void setXl(int xl) {
		this.xl = xl;
	}

	public int getXxl() {
		return xxl;
	}

	public void setXxl(int xxl) {
		this.xxl = xxl;
	}

}
