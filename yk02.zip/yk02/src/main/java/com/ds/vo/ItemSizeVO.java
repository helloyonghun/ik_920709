package com.ds.vo;

public class ItemSizeVO {
	private int item_size_no = 0;
	private int item_no = 0;
	private int size_xs = 0;
	private int size_s = 0;
	private int size_m = 0;
	private int size_l = 0;
	private int size_xl = 0;
	private int size_xxl = 0;

	public int getItem_size_no() {
		return item_size_no;
	}

	public void setItem_size_no(int item_size_no) {
		this.item_size_no = item_size_no;
	}

	public int getItem_no() {
		return item_no;
	}

	public void setItem_no(int item_no) {
		this.item_no = item_no;
	}

	public int getSize_xs() {
		return size_xs;
	}

	public void setSize_xs(int size_xs) {
		this.size_xs = size_xs;
	}

	public int getSize_s() {
		return size_s;
	}

	public void setSize_s(int size_s) {
		this.size_s = size_s;
	}

	public int getSize_m() {
		return size_m;
	}

	public void setSize_m(int size_m) {
		this.size_m = size_m;
	}

	public int getSize_l() {
		return size_l;
	}

	public void setSize_l(int size_l) {
		this.size_l = size_l;
	}

	public int getSize_xl() {
		return size_xl;
	}

	public void setSize_xl(int size_xl) {
		this.size_xl = size_xl;
	}

	public int getSize_xxl() {
		return size_xxl;
	}

	public void setSize_xxl(int size_xxl) {
		this.size_xxl = size_xxl;
	}

}
