package com.ds.vo;

public class Item_IMGVO {
	private int item_no = 0;
	private String file1 = "default.png";
	private String file2 = "default.png";
	private String file3 = "default.png";
	private String item_date = null;

	public int getItem_no() {
		return item_no;
	}

	public void setItem_no(int item_no) {
		this.item_no = item_no;
	}

	public String getFile1() {
		return file1;
	}

	public void setFile1(String file1) {
		this.file1 = file1;
	}

	public String getFile2() {
		return file2;
	}

	public void setFile2(String file2) {
		this.file2 = file2;
	}

	public String getFile3() {
		return file3;
	}

	public void setFile3(String file3) {
		this.file3 = file3;
	}
	public String getItem_date() {
		return item_date;
	}

	public void setItem_date(String item_date) {
		this.item_date = item_date;
	}

}
