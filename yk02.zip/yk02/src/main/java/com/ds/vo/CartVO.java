package com.ds.vo;

public class CartVO {
	private String item_no = null;
	private int cart_no = 0;
	private int cart_cnt = 0;
	private String mem_id = null;
	private String item_size = null;
	private String cart_date = null;

	public CartVO() {

	}

	public CartVO(String item_no, String mem_id, int cart_cnt, String item_size) {
		super();
		this.item_no = item_no;
		this.mem_id = mem_id;
		this.cart_cnt = cart_cnt;
		this.item_size = item_size;
	}
	

	public String getItem_size() {
		return item_size;
	}

	public void setItem_size(String item_size) {
		this.item_size = item_size;
	}

	public int getCart_no() {
		return cart_no;
	}

	public void setCart_no(int cart_no) {
		this.cart_no = cart_no;
	}

	public String getItem_no() {
		return item_no;
	}

	public void setItem_no(String item_no) {
		this.item_no = item_no;
	}

	public int getCart_cnt() {
		return cart_cnt;
	}

	public void setCart_cnt(int cart_cnt) {
		this.cart_cnt = cart_cnt;
	}

	public String getMem_id() {
		return mem_id;
	}

	public void setMem_id(String mem_id) {
		this.mem_id = mem_id;
	}

	public String getCart_date() {
		return cart_date;
	}

	public void setCart_date(String cart_date) {
		this.cart_date = cart_date;
	}

}
