package com.ds.vo;

public class Member {
	private String mem_id = null;
	private String mem_pw = null;
	private int mem_level = 0;
	private String mem_name = null;
	private String mem_path = null;

	private String mem_tel = null;
	private String mem_tel1 = null;
	private String mem_tel2 = null;
	private String mem_telcom = null;
	private String mem_phone = null;
	private String mem_year = null;
	private String mem_month = null;
	private String mem_day = null;
	private int mem_point = 0;
	private String mem_postnum = null;
	private String mem_addr1 = null;
	private String mem_addr2 = null;
	private String mem_delete = null;
	private String mem_date = null;
	private String mem_birth = null;
	
	

	
	
	
	

	public String getMem_telcom() {
		return mem_telcom;
	}

	public void setMem_telcom(String mem_telcom) {
		this.mem_telcom = mem_telcom;
	}

	public String getMem_year() {
		return mem_year;
	}

	public void setMem_year(String mem_year) {
		this.mem_year = mem_year;
	}

	public String getMem_month() {
		return mem_month;
	}

	public void setMem_month(String mem_month) {
		this.mem_month = mem_month;
	}

	public String getMem_day() {
		return mem_day;
	}

	public void setMem_day(String mem_day) {
		this.mem_day = mem_day;
	}

	public String getMem_id() {
		return mem_id;
	}

	public void setMem_id(String mem_id) {
		this.mem_id = mem_id;
	}

	public String getMem_path() {
		return mem_path;
	}

	public void setMem_path(String mem_path) {
		this.mem_path = mem_path;
	}

	public String getMem_pw() {
		return mem_pw;
	}

	public void setMem_pw(String mem_pw) {
		this.mem_pw = mem_pw;
	}

	public int getMem_level() {
		return mem_level;
	}

	public void setMem_level(int mem_level) {
		this.mem_level = mem_level;
	}

	public String getMem_name() {
		return mem_name;
	}

	public void setMem_name(String mem_name) {
		this.mem_name = mem_name;
	}

	public String getMem_tel() {
		return mem_tel;
	}

	public void setMem_tel(String mem_tel) {
		this.mem_tel = mem_tel;
	}

	public String getMem_tel1() {
		return mem_tel1;
	}

	public void setMem_tel1(String mem_tel1) {
		this.mem_tel1 = mem_tel1;
	}

	public String getMem_tel2() {
		return mem_tel2;
	}

	public void setMem_tel2(String mem_tel2) {
		this.mem_tel2 = mem_tel2;
	}

	public int getMem_point() {
		return mem_point;
	}

	public void setMem_point(int mem_point) {
		this.mem_point = mem_point;
	}

	public String getMem_postnum() {
		return mem_postnum;
	}

	public void setMem_postnum(String mem_postnum) {
		this.mem_postnum = mem_postnum;
	}

	public String getMem_addr1() {
		return mem_addr1;
	}

	public void setMem_addr1(String mem_addr1) {
		this.mem_addr1 = mem_addr1;
	}

	public String getMem_addr2() {
		return mem_addr2;
	}

	public void setMem_addr2(String mem_addr2) {
		this.mem_addr2 = mem_addr2;
	}

	public String getMem_delete() {
		return mem_delete;
	}

	public void setMem_delete(String mem_delete) {
		this.mem_delete = mem_delete;
	}

	public String getMem_date() {
		return mem_date;
	}

	public void setMem_date(String mem_date) {
		this.mem_date = mem_date;
	}

	public String getMem_phone() {
		mem_phone = mem_tel + "-" + mem_tel1 + "-" + mem_tel2;
		return mem_phone;
	}

	public void setMem_phone(String mem_phone) {
		this.mem_phone = mem_phone;
	}
	public String getMem_birth() {
		mem_birth = mem_year+ "-"+ mem_month + "-" + mem_day;
		return mem_birth;
	}

	public void setMem_birth(String mem_birth) {
		this.mem_birth = mem_birth;
	}
}
