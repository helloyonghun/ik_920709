package com.ds.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ds.vo.CartVO;
import com.ds.vo.ItemALL;
import com.ds.vo.ItemCartVO;
import com.ds.vo.ItemCategoryVO;
import com.ds.vo.ItemQtyVO;
import com.ds.vo.ItemSizeVO;
import com.ds.vo.ItemSizeVO2;
import com.ds.vo.ItemVO;
import com.ds.vo.Item_IMGVO;
import com.ds.vo.OrderVO;
import com.ds.vo.SelectOrderVO;

@Service
public class ItemDAO {
	@Autowired
	private SqlSession sqlsession = null;
	public List<ItemVO> selectItemList1(Map<String, Object> map) {
		return sqlsession.selectList("Item.getitemlistsmall", map);
	}
	public List<ItemVO> selectItemList2(Map<String, Object> map) {
		return sqlsession.selectList("Item.getitemlistsmall1", map);
	}
	public int getitemcount() {
		return sqlsession.selectOne("Item.itemcount");
	}
	public List<ItemCategoryVO> selectwoman(Map<String,Object> map) {
		System.out.println(map.get("start"));
		return sqlsession.selectList("Item.selectlistwoman",map);
	}
	public List<ItemCategoryVO> selectman(Map<String,Object> map) {
		return sqlsession.selectList("Item.selectlistman",map);
	}
	public List<ItemCategoryVO> selectkids(Map<String,Object> map) {
		return sqlsession.selectList("Item.selectlistkids",map);
	}
	public int updatesize(ItemSizeVO2 item) {
		System.out.println(item.getL());
		return sqlsession.update("Item.updateitemsize",item);
	}
	public ItemSizeVO2 selectitemsize (int item_no) {
		return sqlsession.selectOne("Item.selectsizeitem",item_no);
	}
	public List<SelectOrderVO> selectorderitemimg(Map<String, Object> map) {
		System.out.println(map.get("key_type"));
		System.out.println(map.get("key_text"));
		System.out.println(map.get("start"));
		return sqlsession.selectList("Item.selectorderitemimg", map);
	}
	public int minusqty(ItemQtyVO itemqty) {
		return sqlsession.update("Item.updateitemqty",itemqty);
	}
	public int commitcart(String id) {
		return sqlsession.delete("Item.commitcart", id);
	}
	
	public List<OrderVO> getItemOrderlist(String id) {
		System.out.println(id);
		return sqlsession.selectList("Item.getOrderCartlist", id);
	}

	public int addOrderOne(OrderVO order) {
		return sqlsession.insert("Item.insertorder", order);

	}

	public int deletecartitem(int cart_no) {
		return sqlsession.delete("Item.deletecartitem", cart_no);
	}
	public int getCountlistorder(String id) {
		return sqlsession.selectOne("Item.selectcountorder",id);
	}
	public int getCountlist(String id) {
		return sqlsession.selectOne("Item.selectcountitem", id);
	}

	public List<ItemCartVO> getItemCartMemlist(String id) {
		return sqlsession.selectList("Item.selectcartitem", id);
	}

	public int getitemsumprice(String id) {
		return sqlsession.selectOne("Item.sumprice", id);
	}

	public int addupdatecart(CartVO cart) {
		return sqlsession.insert("Item.addUpdateCart", cart);
	}

	public int getItemListTot(Map<String, Object> map) {
		/*System.out.println(map.get("key_type") + " : " +  map.get("key_text") + " : " + map.get("start"));*/
		return sqlsession.selectOne("Item.getitemlisttot", map);
	}
	public int getOrderlisttot(Map<String, Object> map) {
	/*	System.out.println(map.get("key_type") + " : " +  map.get("key_text") + " : " + map.get("start"));*/
		return sqlsession.selectOne("Item.getorderlisttot", map);
	}
	public List<ItemVO> selectItemList(Map<String, Object> map) {
		try {
			/* System.out.println(map.get("key_type") + "-" + map.get("key_text")+"-"); */
			return sqlsession.selectList("Item.getitemlist", map);
		} catch (Exception e) {
			System.out.println("tgt" + e.getMessage());
			return null;

		}
	}

	public List<CartVO> getitemCartlist(String id) {
		return sqlsession.selectList("Item.getitemcartlist", id);
	}

	public int getcartno(Map<String, String> map) {
		return sqlsession.selectOne("Item.getcartno", map);
	}

	public int insertcart(CartVO cart) {
		return sqlsession.insert("Item.insertcart");
	}

	public List<ItemVO> selectItemList() {
		try {
			return sqlsession.selectList("Item.getitemlist1");
		} catch (Exception e) {
			System.out.println(e.getMessage());
			return null;

		}
	}

	public int insertitem(ItemVO item) {
		/* System.out.println(item.getItem_name() + "dda"); */
		return sqlsession.insert("Item.insertitem", item);

	}
	public int insertitemsize(ItemSizeVO item) {
		return sqlsession.insert("Item.insertitemsize", item);
	}
	public int getLastNo() {
		return sqlsession.selectOne("Item.lastno");
	}
	public int getLastSizeNo() {
		return sqlsession.selectOne("Item.lastsizeno");
	}

	public int insertItemIMG(Item_IMGVO obj) {
		return sqlsession.insert("Item.insertItemimg", obj);
	}

	public ItemVO selectitem(int item_no) {
		System.out.println(item_no);
		return sqlsession.selectOne("Item.getitem1", item_no);

	}

	public int updateitem(ItemVO item) {
		System.out.println("helloworld");
		return sqlsession.update("Item.itemupdate", item);
	}

	public int deleteitem(int item_no) {
		return sqlsession.delete("Item.itemdelete", item_no);
	}

	public int deleteimg(int item_no) {
		return sqlsession.delete("Item.imgdelete", item_no);
	}
	public int deletesize(int item_no) {
		return sqlsession.delete("Item.qtydelete", item_no);
	}

	public ItemALL getitem(int item_no) {
		System.out.println(item_no);
		return sqlsession.selectOne("Item.getimg", item_no);
	}

	public List<ItemALL> getitemlist() {
		return sqlsession.selectList("Item.getimglist");
	}
	public List<ItemALL> getitemlist4() {
		return sqlsession.selectList("Item.getimglist4");
	}
	public List<ItemALL> getitemlist11() {
		return sqlsession.selectList("Item.getimglist11");
	}
	public ItemALL getitemone() {
		return sqlsession.selectOne("Item.getimgOne");
	}
	public ItemALL getitemtwo() {
		return sqlsession.selectOne("Item.getimgTwo");
	}
	public ItemALL getitemthree() {
		return sqlsession.selectOne("Item.getimgThree");
	}
}
