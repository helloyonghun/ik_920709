package com.ds.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ds.vo.Member;

@Service
public class MemberDAO {
	
	@Autowired
	private SqlSession sqlsession = null;
	public Member signlogin(Member mem) {
		return sqlsession.selectOne("Member.signlogin", mem);
	}
	public int editpassword(Member mem) {
		System.out.println(mem.getMem_id());
		System.out.println(mem.getMem_pw());
		return sqlsession.update("Member.changepassword", mem);
	}
	public List<Member> findid (Member mem) {
		System.out.println(mem.getMem_name());
		System.out.println(mem.getMem_year());
		System.out.println(mem.getMem_month());
		System.out.println(mem.getMem_day());
		System.out.println(mem.getMem_tel());
		System.out.println(mem.getMem_tel1());
		System.out.println(mem.getMem_tel2());
		return sqlsession.selectList("Member.findid", mem);
	}
	public Member findpassword(Member mem) {
		System.out.println(mem.getMem_name());
		System.out.println(mem.getMem_year());
		System.out.println(mem.getMem_month());
		System.out.println(mem.getMem_day());
		System.out.println(mem.getMem_tel());
		System.out.println(mem.getMem_tel1());
		System.out.println(mem.getMem_tel2());
		System.out.println(mem.getMem_id());
		System.out.println();
		return sqlsession.selectOne("Member.findpassword", mem);
	}
	public int updatepassword(Member mem) {
		return sqlsession.update("Member.changepassword", mem);
	}
	public int join(Member mem) {
		return sqlsession.insert("Member.insertmember", mem);
	}
	public int memberIDCheck(String id) {
		return sqlsession.selectOne("Member.idCheck",id);
	}
	public Member login(Member mem) {
		return sqlsession.selectOne("Member.userlogin",mem);
	}
	public Member selectmem(String id) {
		return sqlsession.selectOne("Member.selectmember", id);
	}
	public List<Member> selectmem_admin(Map<String, Object> map) {
		System.out.println(map.get("start"));
		return sqlsession.selectList("Member.selectmember_admin" , map);
	}
	public int updatemem(Member mem) {
		return sqlsession.update("Member.updatemember",mem);
	}
	public int deletemem(Map<String, String> mem) {
		System.out.println(mem.get("mem_id") + "//" + mem.get("mem_pw"));
		return sqlsession.update("Member.deletemem",mem);
	}
	public int getMemberCount() {
		return sqlsession.selectOne("Member.getmembercount");
	}
	public List<Member> select_block_member() {
		return sqlsession.selectList("Member.selectblocklist");
	}
}
