package com.ds.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ds.vo.Mail;

@Service
public class MailDAO {
	@Autowired
	private SqlSession sqlsession = null;
	public int insertmail(Mail mail) {
		return sqlsession.insert("Mail.mailwrite",mail);
	}
	public List<Mail> selectlist(Map<String, Object> map) {
		return sqlsession.selectList("Mail.selectmaillist", map);
	}
	public Mail getMailContent(int mail_no) {
		return sqlsession.selectOne("Mail.MailContent",mail_no);
	}
	public int getMailCount() {
		return sqlsession.selectOne("Mail.getMailCount");
	}
	public int complete_answer(int mail_no) {
		return sqlsession.delete("Mail.complete_answer", mail_no);
	}
}
