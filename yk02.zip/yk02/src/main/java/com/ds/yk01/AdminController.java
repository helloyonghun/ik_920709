package com.ds.yk01;

import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.mail.internet.MimeMessage;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.ds.common.UploadClass;
import com.ds.dao.ItemDAO;
import com.ds.dao.MailDAO;
import com.ds.dao.MemberDAO;
import com.ds.vo.ItemSizeVO;
import com.ds.vo.ItemSizeVO2;
import com.ds.vo.ItemVO;
import com.ds.vo.Item_IMGVO;
import com.ds.vo.Mail;
import com.ds.vo.Member;
import com.ds.vo.SelectOrderVO;

//search_type
@Controller
public class AdminController {
	@Autowired
	ItemDAO idao = new ItemDAO();
	@Autowired
	MemberDAO mdao = new MemberDAO();
	@Autowired
	MailDAO maildao = new MailDAO();
	@Autowired
	private JavaMailSender mailSender;

	private final String[] menu = { "상품관리", "주문관리", "회원관리", "문의관리" };
	Map<String, String> item_category = new HashMap<String, String>();
	Map<String, String> item_category1 = new HashMap<String, String>();
	Map<String, String> item_size = new HashMap<String, String>();

	// 문의 메일 답장하기
	@RequestMapping(value = "/admin_answer.do")
	public String mail(@RequestParam("mail_no") int mail_no, HttpServletRequest request) {
		Mail mail = maildao.getMailContent(mail_no);
		String mail1 = "제목  : " + mail.getMail_title() + "\n";
		String mail2 = "보낸이 : " + mail.getMem_id() + "\n";
		String mail3 = "글 내용 : " + mail.getContent() + "\n";
		String mail4 = "-------------------------------------------------------------------------------------------------"
				+ "\n";
		String synthesis = mail1 + mail2 + mail3 + mail4;
		String title1 = "문의하신 내용입니다.";
		request.setAttribute("mail_no", mail_no);
		request.setAttribute("mail", mail);
		request.setAttribute("mailtitle", title1);
		request.setAttribute("mailcontent", synthesis);
		request.setAttribute("strmenu", menu);
		return "admin_answer";
	}

	@RequestMapping(value = "/admin_answer1.do")
	public String mailSending(HttpServletRequest request, @RequestParam("mail_no") int mail_no) {
		String setfrom = "testworld253@gmail.com";
		String tomail = request.getParameter("tomail");
		String title = request.getParameter("title");
		String context = request.getParameter("context");

		try {
			MimeMessage message = mailSender.createMimeMessage();
			MimeMessageHelper messageHelper = new MimeMessageHelper(message, true, "UTF-8");
			messageHelper.setFrom(setfrom);
			messageHelper.setTo(tomail);
			messageHelper.setSubject(title);
			messageHelper.setText(context);

			mailSender.send(message);
			// 메일 보내는 것이 완료가 되면 문의 메일을 삭제
			int ret = maildao.complete_answer(mail_no);
			System.out.println(ret);
			return "redirect:/admin.do?menu=4";
		} catch (Exception e) {
			System.out.println(e.getMessage());
			return "";
		}

	}

	@RequestMapping(value = "admin_view_details.do", method = RequestMethod.GET)
	public String admin_size_detail(@RequestParam("item_no") int item_no, Model model, HttpServletRequest request) {
		ItemSizeVO2 item = idao.selectitemsize(item_no);
		model.addAttribute("item", item);
		request.setAttribute("strmenu", menu);
		return "admin_view_details";

	}

	@RequestMapping(value = "admin_view_details.do", method = RequestMethod.POST)
	public String admin_size_update(@RequestParam("item_no") int item_no, @RequestParam("xs") int item_xs,
			@RequestParam("s") int s, @RequestParam("m") int m, @RequestParam("l") int l, @RequestParam("xl") int xl,
			@RequestParam("xxl") int xxl, ItemSizeVO2 item2) {
		try {
			item2.setItem_no(item_no);
			item2.setXs(item_xs);
			item2.setS(s);
			item2.setM(m);
			item2.setL(l);
			item2.setXl(xl);
			item2.setXxl(xxl);
			System.out.println(item2.getXs());
			idao.updatesize(item2);
			return "redirect:/admin.do";
		} catch (Exception e) {
			System.out.println(e.getMessage());
			return null;
		}
	}

	@RequestMapping(value = "admin_delete_item.do", method = RequestMethod.GET)
	public String admin_delete_item(@RequestParam("item_no") int item_no) {
		idao.deleteimg(item_no);
		idao.deleteitem(item_no);
		idao.deletesize(item_no);
		return "redirect:/admin.do?menu=1";
	}

	@RequestMapping(value = "admin_update_item.do", method = RequestMethod.GET)
	public String admin_update_item_get(@ModelAttribute("command") ItemVO item, @RequestParam("item_no") int item_no,
			Model model, HttpServletRequest request) {
		item_category.put("mem", "남성");
		item_category.put("woman", "여성");
		item_category.put("kids", "어린이");
		model.addAttribute("item_category", item_category);
		item_category1.put("top", "상의");
		item_category1.put("buttom", "하의");
		item_category1.put("shoes", "신발");
		item_category1.put("cap", "모자");

		/*
		 * item_size.put("XS", "XS"); item_size.put("S", "S"); item_size.put("M", "M");
		 * item_size.put("L", "L"); item_size.put("XL", "XL");
		 * model.addAttribute("item_size",item_size);
		 */
		model.addAttribute("item_category1", item_category1);
		request.setAttribute("strmenu", menu);
		ItemVO item2 = idao.selectitem(item_no);
		model.addAttribute("command", item2);

		return "admin_update_item";
	}

	@RequestMapping(value = "admin_update_item.do", method = RequestMethod.POST)
	public String admin_update_item_post(@ModelAttribute("command") ItemVO item,
			@RequestParam(value = "item_no") int item_no, HttpServletRequest request) {
		// int ret = idao.insertitem(item);
		int ret = idao.updateitem(item);
		if (ret > 0) {
			System.out.println("수정 성공");
			return "redirect:/admin.do?menu=1";
		} else {
			System.out.println("수정 실패");
			return "redirect:insertitem.do";
		}

	}

	@RequestMapping(value = "admin_item_size.do", method = RequestMethod.GET)
	public String admin_item_size_get(@ModelAttribute("command") ItemSizeVO item, @RequestParam("item_no") int item_no,
			Model model, HttpServletRequest request) {
		int lastno = idao.getLastSizeNo() + 1;
		if (lastno == 0) {
			lastno = lastno + 100000;
		}
		idao.selectitem(item_no);
		model.addAttribute("last_no", lastno);
		model.addAttribute("item_no", item_no);
		request.setAttribute("strmenu", menu);
		return "admin_addclothsize";
	}

	@RequestMapping(value = "admin_item_size.do", method = RequestMethod.POST)
	public String admin_item_size_post(@ModelAttribute("command") ItemSizeVO item, HttpServletRequest request) {
		int ret = idao.insertitemsize(item);
		if (ret > 0)
			System.out.println("성공 " + ret);
		else
			System.out.println("실패" + ret);
		return "redirect:admin.do";
	}

	@RequestMapping(value = "admin_item_img.do", method = RequestMethod.GET)
	public String admin_item_img_get(@RequestParam("item_no") int item_no, Model model, HttpServletRequest request) {
		request.setAttribute("strmenu", menu);
		System.out.println(item_no);
		idao.selectitem(item_no);
		Item_IMGVO item1 = new Item_IMGVO();
		item1.setItem_no(item_no);
		model.addAttribute("item_no", item_no);

		return "admin_item_img";
	}

	@RequestMapping(value = "admin_item_img.do", method = RequestMethod.POST)
	public String admin_item_img_post(@RequestParam(value = "item_no") int item_no,
			MultipartHttpServletRequest request) {
		// 절대 경로 가져오기
		String root = request.getSession().getServletContext().getRealPath("/");
		System.out.println(root);
		try {
			Map<String, MultipartFile> map = request.getFileMap();
			Item_IMGVO obj = new Item_IMGVO();
			obj.setItem_no(item_no);

			System.out.println(obj.getItem_no());

			for (int i = 0; i < map.size(); i++) {
				MultipartFile mFile = map.get("a" + i);
				if (mFile != null && !mFile.getOriginalFilename().equals("")) {
					// 확장자
					String ext = UploadClass.getExt(mFile.getOriginalFilename());
					// 파일명 변경
					String newFile = UploadClass.getUUid() + ext;
					// 빈 파일 생성
					File tmpfile = new File(root + "resources" + File.separator + "images" + File.separator + newFile);
					// 파일 복사
					mFile.transferTo(tmpfile);
					if (i == 0) {
						obj.setFile1(newFile);
					}
					if (i == 1) {
						obj.setFile2(newFile);
					}
					if (i == 2) {
						obj.setFile3(newFile);
					}
				}
			}

			int ret = idao.insertItemIMG(obj);
			if (ret > 0) {
				System.out.println("성공");
				return "redirect:/admin.do?menu=1";
			} else {
				System.out.println("실패");
				return null;
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
			return null;
		}

	}

	@RequestMapping(value = "admin_content.do", method = RequestMethod.GET)
	public String admin_content(HttpServletRequest request, @RequestParam("mail_no") int mail_no) {
		return "redirect:admin_content1.do?mail_no=" + mail_no;
	}

	@RequestMapping(value = "admin_content1.do", method = RequestMethod.GET)
	public String admin_content1(@RequestParam("mail_no") int mail_no, Model model, HttpServletRequest request) {
		Mail mail = maildao.getMailContent(mail_no);
		request.setAttribute("strmenu", menu);
		model.addAttribute("mail", mail);
		return "admin_help_content";
	}

	@RequestMapping(value = "/admin.do", method = RequestMethod.GET)
	public String home(@RequestParam(value = "pages", defaultValue = "1") int page,
			@RequestParam(value = "type", defaultValue = "item_name") String type,
			@RequestParam(value = "text", defaultValue = "") String text, HttpServletRequest request,
			HttpServletResponse response, Model model) throws IOException {

		String m = request.getParameter("menu");
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		// 만일 menu가 null일때...
		if (m == null) {
			return "redirect:admin.do?menu=1&pages=" + page;
		}
		// 상품관리
		if (m.equals("1")) {
			int start = (page - 1) * 5;

			Map<String, Object> map = new HashMap<String, Object>();
			map.put("key_type", type);
			map.put("key_text", text);
			map.put("start", start);

			System.out.println("Hello World2");

			// 총 갯수 구하기
			int tot = idao.getItemListTot(map);
			int pages = ((tot - 1) / 5 + 1);
			model.addAttribute("pages", pages);
			System.out.println(type);
			System.out.println(text);

			// image1
			List<ItemVO> list = idao.selectItemList(map);

			request.setAttribute("list", list);

		} else if (m.equals("2")) {
			if (type.equals("item_name")) {
				type = "order_no"; // 상품 코드
			}

			int start = (page - 1) * 5;

			Map<String, Object> map = new HashMap<String, Object>();
			map.put("key_type", type);
			map.put("key_text", text);
			map.put("start", start);
			System.out.println(text);

			List<SelectOrderVO> list = idao.selectorderitemimg(map);
			int tot = idao.getOrderlisttot(map);
			int pages = ((tot - 1) / 5 + 1);
			model.addAttribute("pages", pages);
			System.out.println(list.size());
			request.setAttribute("list3", list);
		}
		// 회원관리
		else if (m.equals("3")) {

			int tot = mdao.getMemberCount();
			int pages = ((tot - 1) / 5 + 1);

			int start = (page - 1) * 5;
			Map<String, Object> map = new HashMap<String, Object>();
			map.put("start", start);
			List<Member> list = mdao.selectmem_admin(map);
			model.addAttribute("pages", pages);
			request.setAttribute("list1", list);
		}
		// 문의 관리
		else if (m.equals("4")) {
			Map<String, Object> map = new HashMap<String, Object>();
			int tot = maildao.getMailCount();
			int pages = ((tot - 1) / 5 + 1);
			int start = (page - 1) * 5;
			map.put("start", start);
			List<Mail> list = maildao.selectlist(map);
			System.out.println(list.size());
			model.addAttribute("pages", pages);
			request.setAttribute("list2", list);
		}
		request.setAttribute("strmenu", menu);
		return "admin";
	}

	@RequestMapping(value = "/insertitem.do", method = RequestMethod.GET)
	public String item_get(Model model, HttpServletRequest request) {
		ItemVO item = new ItemVO();
		// 마지막 번호 받아오기
		int lastno = idao.getLastNo() + 1;
		// 만일 처음입력할시....
		if (lastno == 0) {
			lastno = lastno + 100000;
		}
		item_category.put("mem", "남성");
		item_category.put("woman", "여성");
		item_category.put("kids", "어린이");
		model.addAttribute("item_category", item_category);

		item_category1.put("top", "상의");
		item_category1.put("buttom", "하의");
		item_category1.put("shoes", "신발");
		item_category1.put("cap", "모자");

		/*
		 * item_size.put("XS", "XS"); item_size.put("S", "S"); item_size.put("M", "M");
		 * item_size.put("L", "L"); item_size.put("XL", "XL");
		 * 
		 * model.addAttribute("item_size",item_size);
		 */
		model.addAttribute("item_category1", item_category1);
		model.addAttribute("lastno", lastno);
		request.setAttribute("strmenu", menu);
		model.addAttribute("command", item);
		return "admin_additem";
	}

	@RequestMapping(value = "/insertitem.do", method = RequestMethod.POST)
	public String item_post(@ModelAttribute("command") ItemVO item, HttpServletRequest request) {
		try {
			request.getParameter("menu");
			int ret = idao.insertitem(item);
			System.out.println(item.getItem_name());
			System.out.println(item.getItem_no());
			if (ret > 0) {
				System.out.println("등록 성공");
				return "redirect:/admin.do?menu=1";
			} else {
				System.out.println("등록 실패");
				return "redirect:insertitem.do";
			}

		} catch (Exception e) {
			System.out.println(e.getMessage());
			return "redirect:insertitem.do";
		}
	}
}
