package com.ds.yk01;

import java.util.Properties;

import javax.mail.Address;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.ds.dao.MailDAO;
import com.ds.vo.Mail;

@Controller
@ComponentScan("com.ds.dao")
public class MailController {
	@Autowired
	private MailDAO maildao = null;
	
	@RequestMapping(value = "mail.do", method = RequestMethod.GET)
	public String mailget(HttpSession httpsession, Model model) {
		String id = (String) httpsession.getAttribute("_id");
		String name = (String)httpsession.getAttribute("_name");
		if(id == null || id.equals("")) {
			return "redirect:login.do";
		}
		else {
			Mail mail = new Mail();
			mail.setMem_id(id);
			mail.setMem_name(name);
			System.out.println(mail.getMem_id());
			model.addAttribute("command", mail);
			httpsession.setAttribute("mem_id", mail.getMem_id());
			httpsession.setAttribute("mem_name", mail.getMem_name());
			return "mail";
		}
	}
	@RequestMapping(value = "mail.do", method = RequestMethod.POST)
	public String mailpost(Model model, HttpSession httpsession, @ModelAttribute("command")Mail mail) {
		int ret = maildao.insertmail(mail);
		if(ret >0) {
			return "redirect:main.do";
		}
		else return "redirect:mail.do";
	}
}
