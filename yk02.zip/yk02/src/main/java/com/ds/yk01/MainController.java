package com.ds.yk01;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.ds.dao.ItemDAO;
import com.ds.vo.ItemALL;
import com.ds.vo.ItemVO;



@Controller
@ComponentScan("com.ds.dao")
public class MainController {
	
//	@Autowired
//	private BlogDAO blogDAO;
	@Autowired
	ItemDAO idao = new ItemDAO();
	
	@RequestMapping(value="/main.do", method = RequestMethod.GET)
	public String main(Model model){
		List<ItemALL> item = idao.getitemlist();
		List<ItemALL> item4 = idao.getitemlist4();
		ItemALL item1 = idao.getitemone();
		ItemALL item2 = idao.getitemtwo();
		ItemALL item3 = idao.getitemthree();
		Map<String, String> map = new HashMap<String, String>();
		map.put("xs", "xs");
		map.put("s", "s");
		map.put("m", "m");
		map.put("l", "l");
		map.put("xl", "xl");
		map.put("xxl", "xxl");
		model.addAttribute("item_size",map);
		model.addAttribute("item",item);
		model.addAttribute("item1",item1);
		model.addAttribute("item4",item4);
		
		model.addAttribute("item2", item2);
		model.addAttribute("item3",item3);
		return "main";
	}
	@RequestMapping(value="/short_code.do", method = RequestMethod.GET)
	public String short_code(){
		
		return "short_code";
	}
	@RequestMapping(value="/preview_item.do", method = RequestMethod.GET)
	public String shop_preview(){
		return "shop_item_view";
	}
	@RequestMapping(value = "single1.do", method = RequestMethod.GET) 
	public String single1(HttpServletRequest request, @RequestParam("item_no")int item_no) {
		return "redirect:single.do?item_no="+item_no;
	}
	@RequestMapping(value="/single.do", method = RequestMethod.GET)
	public String single(@RequestParam("item_no") int item_no,@RequestParam(value = "pages", defaultValue = "1") int page, HttpServletRequest request, Model model){
		ItemALL item = idao.getitem(item_no);
		List<ItemALL> item1 = idao.getitemlist();
		List<ItemALL> item2 = idao.getitemlist11();
		Map<String, String> map = new HashMap<String, String>();
		Map<String, Object> map1 = new HashMap<String,Object>();
		
		
		int start = (page-1) * 3;
		map1.put("start", start);
		
		
		map.put("xs", "xs");
		map.put("s", "s");
		map.put("m", "m");
		map.put("l", "l");
		map.put("xl", "xl");
		map.put("xxl", "xxl");
		model.addAttribute("item_size",map);
		model.addAttribute("item1",item1);
		model.addAttribute("item", item);
		model.addAttribute("item11", item2);
	
		List<ItemVO> list3 = idao.selectItemList2(map1);
		request.setAttribute("list3", list3);
		
		return "single";
	}
	@RequestMapping(value = "/pagenotfound.do", method = RequestMethod.GET) 
	public String pagenotfound() {
		return "pagenotfound";
	}

}
