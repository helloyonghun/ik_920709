package com.ds.yk01;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.ds.dao.ItemDAO;
import com.ds.vo.ItemALL;
import com.ds.vo.ItemCategoryVO;
import com.ds.vo.ItemVO;

@Controller
@ComponentScan("com.ds.dao")
public class ProductController {
	@Autowired
	ItemDAO idao = new ItemDAO();
	@RequestMapping(value = "/product.do", method = RequestMethod.GET)
	public String memproduct(HttpServletRequest request, Model model,@RequestParam(value = "pages", defaultValue = "1") int page) {
		Map<String, Object> map = new HashMap<String, Object>();
		Map<String, String> map1 = new HashMap<String, String>();
		int tot = idao.getitemcount();
		System.out.println(tot);
		int pages = ((tot - 1) / 3 + 1);
		int start = (page-1) * 3;
		map.put("start", start);
		List<ItemCategoryVO> list = idao.selectwoman(map);
		List<ItemCategoryVO> list1 = idao.selectman(map);
		List<ItemCategoryVO> list2 = idao.selectkids(map);
		List<ItemVO> list3 = idao.selectItemList1(map);
		model.addAttribute("pages",pages);
		map1.put("xs", "xs");
		map1.put("s", "s");
		map1.put("m", "m");
		map1.put("l", "l");
		map1.put("xl", "xl");
		map1.put("xxl", "xxl");
		model.addAttribute("item_size",map1);
		
		request.setAttribute("list", list);
		request.setAttribute("list1", list1);
		request.setAttribute("list2", list2);
		request.setAttribute("list3", list3);
		return "product";
	}
}
