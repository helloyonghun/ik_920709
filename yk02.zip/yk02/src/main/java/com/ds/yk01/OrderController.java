package com.ds.yk01;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.ds.dao.ItemDAO;
import com.ds.vo.CartVO;
import com.ds.vo.ItemCartVO;
import com.ds.vo.ItemQtyVO;
import com.ds.vo.OrderVO;

@Controller
@ComponentScan("com.ds.dao")
public class OrderController {
	@Autowired
	private ItemDAO idao;

	@RequestMapping(value = "deletecartitem.do", method = RequestMethod.GET)
	public String delete_cartitem_get(@RequestParam("cart_no") int cart_no) {
		idao.deletecartitem(cart_no);
		return "redirect:/checkout.do";
	}

	@RequestMapping(value = "/checkout.do", method = RequestMethod.GET)
	public String checkout_get(Model model, HttpSession httpsession) {
		try {
			String id = (String) httpsession.getAttribute("_id");
			List<CartVO> list = idao.getitemCartlist(id);
			model.addAttribute("list", list);
			List<ItemCartVO> lists = idao.getItemCartMemlist(id);
			model.addAttribute("itemcartlist", lists);
			int ret = idao.getCountlist(id);
			model.addAttribute("ret", ret);
			int ret1 = idao.getitemsumprice(id);
			model.addAttribute("ret1", ret1);
			System.out.println(ret1);
			System.out.println(ret);

			return "checkout";
		} catch (Exception e) {
			System.out.println(e.getMessage());
			return null;
		}
	}

	@RequestMapping(value = "/checkout.do", method = RequestMethod.POST)
	public String checkout_post(Model model, HttpSession httpsession, @RequestParam("item_no") String item_no,
			@RequestParam(value = "cart_cnt", defaultValue = "1") int cnt, @RequestParam(value = "item_size", defaultValue = "ms") String item_size) {
		String mem_id = (String) httpsession.getAttribute("_id");
		Map<String, String> map = new HashMap<String, String>();
		map.put("map1", item_no);
		map.put("map2", mem_id);
		System.out.println(item_no);
		System.out.println(mem_id);
		int no = idao.getcartno(map);

		CartVO cart = new CartVO(item_no, mem_id, cnt,item_size);
		cart.setCart_no(no);

		try {
			idao.addupdatecart(cart);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return "redirect:checkout.do";
	}

	@RequestMapping(value = "/insertorder.do", method = RequestMethod.POST)
	public String order_post(Model model, HttpSession httpsession, @RequestParam("item_no[]") int[] item_no,
			@RequestParam("item_name[]") String[] item_name, @RequestParam("cart_cnt[]") int[] order_cnt,
			@RequestParam("item_price[]") int[] item_price, @RequestParam("order_coin") String order_coin,
			@RequestParam("item_size[]")String[] item_size) {
		String mem_id = (String) httpsession.getAttribute("_id");

		// 만일 처음 입력할 시.....
		OrderVO order = new OrderVO();
		ItemQtyVO itemqty = new ItemQtyVO();
		
		for (int i = 0; i < item_no.length; i++) {
			// 마지막 번호 호출

			order.setMem_id(mem_id);
			order.setItem_no(item_no[i]);
			order.setOrder_cnt(order_cnt[i]);
			order.setItem_price(item_price[i]);
			order.setItem_name(item_name[i]);
			order.setOrder_coin(order_coin);
			order.setItem_size(item_size[i]);
			

			itemqty.setItem_no(item_no[i]);
			itemqty.setItem_size(item_size[i]);
			itemqty.setOrder_cnt(order_cnt[i]);
			
			System.out.println(itemqty.getItem_no() + "  hello1");
			System.out.println(itemqty.getItem_size() + " hello2");
			System.out.println(itemqty.getOrder_cnt() + " hello3");
			System.out.println(order_cnt[i]);
			idao.addOrderOne(order);
			int ret = idao.minusqty(itemqty);
			System.out.println(ret);
			/*System.out.println(ret + "hello");*/
			idao.commitcart(mem_id);
		
		}
		return "redirect:insertorder.do";
	}

	@RequestMapping(value = "/insertorder.do", method = RequestMethod.GET)
	public String order_get(Model model, HttpSession httpsession) {
		try {
			String mem_id = (String) httpsession.getAttribute("_id");
			List<OrderVO> list = idao.getItemOrderlist(mem_id);
			int ret = idao.getCountlistorder(mem_id);
			model.addAttribute("ret",ret);
			System.out.println(list.size());
			model.addAttribute("list", list);
			return "insertorder";
		} catch (Exception e) {
			System.out.println(e.getMessage());
			return null;
		}

	}

}
