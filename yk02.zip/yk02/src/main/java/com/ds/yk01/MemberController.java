package com.ds.yk01;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ds.dao.MemberDAO;
import com.ds.vo.Member;

@Controller
@ComponentScan("com.ds.dao")
public class MemberController {
	@Autowired
	private MemberDAO mdao = null;
	@RequestMapping(value = "/delete.do", method = RequestMethod.GET)
	public String delete_get(HttpServletRequest request,HttpSession httpsession) {
		String id = (String) httpsession.getAttribute("_id");
		Member mem = mdao.selectmem(id);
		request.setAttribute("mem_id", mem.getMem_id());
		return "deletemem";
	}
	@RequestMapping(value = "/delete.do", method = RequestMethod.POST)
	public String delete_post(@RequestParam("mem_id") String mem_id, @RequestParam("mem_pw") String mem_pw ,Model model, HttpSession httpsession) {
		try {
			Map<String, String> mem = new HashMap<String, String>();
			mem.put("mem_id", mem_id);
			mem.put("mem_pw", mem_pw);
			int r = mdao.deletemem(mem);
			System.out.println(r);
			if(r == 0) {
				return "redirect:/delete.do";
			}
			else {
				httpsession.invalidate();
				return "redirect:main.do";
			}
		}
		catch(Exception e) {
			System.out.println(e.getMessage());
			return null;
		}
	}
	@RequestMapping(value = "/edit.do", method = RequestMethod.GET)
	public String edit_get(Model model,HttpSession httpsession) {
		String id = (String)httpsession.getAttribute("_id");
		Member mem = mdao.selectmem(id);
		model.addAttribute("mem", mem);
		
		return "edit";
	}
	@RequestMapping(value = "/edit.do", method = RequestMethod.POST)
	public String edit_post(@ModelAttribute("mem") Member mem, Model model,HttpSession httpsession) {
		try {
			int r = mdao.updatemem(mem);
			if (r > 0) {
				httpsession.setAttribute("_name", mem.getMem_name());
				System.out.println("성공");
				return "redirect:/main.do";
			} else {
				System.out.println("실패");
				return "redirect:/edit.do";
			}
			
		}
		catch(Exception e) {
			System.out.println(e.getMessage());
			return null;
		}
	}
	@RequestMapping(value = "/join.do", method = RequestMethod.GET)
	public String getjoin(Model model) {
		Member mem = new Member();
		model.addAttribute("command", mem);
		return "join";
	}
	

	@RequestMapping(value = "/join.do", method = RequestMethod.POST)
	public String postjoin(@ModelAttribute("command") Member mem) {

		try {
			int r = mdao.join(mem);
			System.out.println(mem.getMem_id());
			System.out.println(mem.getMem_name());
			if (r > 0) {
				System.out.println("성공");
			} else {
				System.out.println("실패");
			}
			return "redirect:/main.do";
		} catch (Exception e) {
			System.out.println(e.getMessage());
			return null;
		}
	}

	@RequestMapping(value = "/login.do", method = RequestMethod.GET)
	public String login_get(Model model) {
		Member mem = new Member();
		model.addAttribute("command",mem);
		return "login";
	}

	@RequestMapping(value = "/login.do", method = RequestMethod.POST)
	public String login_post(@ModelAttribute("command") Member mem, HttpSession httpsession) {
		try {
			Member ret = mdao.login(mem);
			System.out.println(ret.getMem_name());
			httpsession.setAttribute("_id", ret.getMem_id());
			httpsession.setAttribute("_name", ret.getMem_name());
			httpsession.setAttribute("_point", ret.getMem_point());
			String r_url = (String)httpsession.getAttribute("r_url");
			if(r_url != null) {
				return "redirect:"+r_url;
			}
			else return "redirect:/main.do";
			
		}
		catch(Exception e) {
			System.out.println(e.getMessage());
			return null;
		}
	}

	@RequestMapping(value = "/logout.do", method = RequestMethod.GET)
	public String logout(HttpServletRequest request) {
		HttpSession httpsession = request.getSession();
		httpsession.invalidate();
		System.out.println(httpsession);
		return "redirect:/main.do";
	}

	@RequestMapping(value = "/app_idcheck", method = { RequestMethod.GET, RequestMethod.POST })
	// {"key":"value", "key","value"}
	public @ResponseBody HashMap<String, String> idCheck(HttpServletRequest request, HttpServletResponse response) {
		// <input type="text" name="id"> 스마트폰개발자
		// <a href="서버주소?id=XXX" 서버개발자는 이렇게 확인

		/* 크로스 도메인 아래 여섯줄 */
		response.setHeader("Access-Control-Allow-Methods", "POST, GET, OPTIONS, DELETE");
		response.setHeader("Access-Control-Max-Age", "3600");
		response.setHeader("Access-Control-Allow-Headers", "x-requested-with");
		response.setHeader("Access-Control-Allow-Origin", "*");
		response.setContentType("application/json");
		response.setCharacterEncoding("UTF-8");

		String id = request.getParameter("id");
		int ret = mdao.memberIDCheck(id);
		HashMap<String, String> map = new HashMap<String, String>();
		map.put("ret", "n");

		if (ret == 1) {
			// {"ret":"y"}
			map.put("ret", "y");
		}
		// @ResponseBody는 화면이 아니고 문서로 리턴하겠다. jsp호출을 막는다
		return map;
	}
	
	@RequestMapping(value = "/findid.do", method = RequestMethod.GET)
	public String findidget(Model model, HttpSession httpsession){
		return "forgotid";
	}
	@RequestMapping(value = "/findid.do", method = RequestMethod.POST)
	public String findidpost(Model model, HttpServletRequest request, HttpSession httpsession,
			@RequestParam("mem_name") String mem_name, @RequestParam("mem_tel") String mem_tel,
			@RequestParam("mem_tel1") String mem_tel1, @RequestParam("mem_tel2") String mem_tel2,@RequestParam("mem_year") String year,
			@RequestParam("mem_month") String mem_month, @RequestParam("mem_day") String mem_day) {
			Member mem = new Member();
			mem.setMem_name(mem_name);
			mem.setMem_tel(mem_tel);
			mem.setMem_tel1(mem_tel1);
			mem.setMem_tel2(mem_tel2);
			mem.setMem_year(year);
			mem.setMem_month(mem_month);
			mem.setMem_day(mem_day);
			
			List<Member> ret = mdao.findid(mem);
			System.out.println();
			System.out.println();
			System.out.println(ret.size());
			httpsession.setAttribute("list", ret);
			
			
			return "redirect:/findidresult.do";
		}
	@RequestMapping(value = "/findidresult.do", method = RequestMethod.GET)
	public String findidresult(Model model, HttpSession httpsession){
		ArrayList<Member> id = (ArrayList<Member>)httpsession.getAttribute("list");
		System.out.println(id);
		model.addAttribute("id",id);
		
		return "idresult";
		
	
	}
	@RequestMapping(value = "/findpassword.do", method = RequestMethod.GET)
	public String findpasswordget(Model model, HttpSession httpsession){
		return "forgotpassword";
	}
	@RequestMapping(value = "/findpassword.do", method = RequestMethod.POST)
	public String findpasswordpost(Model model, HttpSession httpsession,	@RequestParam("mem_name") String mem_name, @RequestParam("mem_tel") String mem_tel,
			@RequestParam("mem_tel1") String mem_tel1, @RequestParam("mem_tel2") String mem_tel2,@RequestParam("mem_year") String year,
			@RequestParam("mem_month") String mem_month, @RequestParam("mem_day") String mem_day, @RequestParam("mem_id") String mem_id){
		Member mem = new Member();
		mem.setMem_id(mem_id);
		mem.setMem_name(mem_name);
		mem.setMem_tel(mem_tel);
		mem.setMem_tel1(mem_tel1);
		mem.setMem_tel2(mem_tel2);
		mem.setMem_year(year);
		mem.setMem_month(mem_month);
		mem.setMem_day(mem_day);
		mdao.findpassword(mem);
		httpsession.setAttribute("_findid", mem.getMem_id());
		
		return "redirect:/changepassword.do";
	}
	@RequestMapping(value = "/changepassword.do", method = RequestMethod.GET)
	public String changepasswordget(Model model, HttpSession httpsession) {
		String mem = (String)httpsession.getAttribute("_findid");
		model.addAttribute("mem",mem);
		return "changepassword";
	}
	@RequestMapping(value = "/changepassword.do", method = RequestMethod.POST)
	public String changepasswordpost(Model model, HttpSession httpsession, @RequestParam("mem_id") String mem_id, @RequestParam("mem_pw") String mem_pw) {
		Member mem = new Member();
		mem.setMem_id(mem_id);
		mem.setMem_pw(mem_pw);
		mdao.updatepassword(mem);
		return "redirect:/main.do";
	}
	
	@RequestMapping(value = "/editpassword.do", method = RequestMethod.GET) 
	public String editpassswordget(Model model, HttpSession httpsession) {
		String id = (String)httpsession.getAttribute("_id");
		Member mem = mdao.selectmem(id);
		model.addAttribute("mem_id", mem.getMem_id());
		return "editpassword";
	}
	@RequestMapping(value = "/editpassword.do", method = RequestMethod.POST)
	public String editpasswordpost(Model model, HttpSession httpsession, @RequestParam("mem_id") String mem_id, @RequestParam("mem_pw") String mem_pw) {
		Member mem =  new Member();
		mem.setMem_id(mem_id);
		mem.setMem_pw(mem_pw);
		int ret = mdao.editpassword(mem);
		if(ret > 0) {
			System.out.println(ret);
			return "redirect:/main.do";
		}
		else {
			System.out.println(ret);
			return "redirect:/editpassword.do";
		}
	}
	@RequestMapping(value = "/signlogin.do", method = RequestMethod.GET)
	public String signloginget(Model model, HttpSession httpsession){
		String id = (String)httpsession.getAttribute("_id");
		Member mem = mdao.selectmem(id);
		model.addAttribute("mem_id", mem.getMem_id());
		return "signlogin";
	}
	@RequestMapping(value = "/signlogin.do", method = RequestMethod.POST)
	public String signloginpost(Model model, @RequestParam("mem_id") String mem_id, @RequestParam("mem_pw")String mem_pw) {
		try {
			Member mem = new Member();
			mem.setMem_id(mem_id);
			mem.setMem_pw(mem_pw);
			mdao.signlogin(mem);
			return "redirect:/editpassword.do";
		}
		catch(Exception e) {
			e.getMessage();
			return null;
		}
	}
}


