package com.ds.common;

import java.util.UUID;

public class UploadClass {
	public static String getExt(String fileName){
		int last = fileName.lastIndexOf(".");
		return fileName.substring(last);
	}
	
	public static String getUUid(){
		String tmp = UUID.randomUUID().toString().replaceAll("-", "");
		return System.currentTimeMillis()+tmp;
	}
}