package com.ds.interceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;


public class MainInterceptor extends HandlerInterceptorAdapter {
	@Override
	public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler,
			ModelAndView modelAndView) throws Exception {
		// TODO Auto-generated method stub
		super.postHandle(request, response, handler, modelAndView);
	}
	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		
		System.out.println("Interceptor : PreHandle");

		// TODO Auto-generated method stub

/*
		System.out.println("----------------------");
		System.out.println(request.getServletPath() + "?" + request.getQueryString());
		System.out.println("----------------------");


		String path = request.getServletPath();
		String query = request.getQueryString();
		HttpSession httpSession = request.getSession();
		//System.out.println(path.contains("login"));

		if(!path.contains("login")){
			if(query != null){
				httpSession.setAttribute("r_url", path+"?"+query);	
			}
			else{
				httpSession.setAttribute("r_url",path);
			}
			
		}
*/
		HttpSession httpsession = request.getSession();
		String userid = (String)httpsession.getAttribute("_id");
		if(userid == null) {
			System.out.println("Inteceptor : Session Check Fail");
			response.sendRedirect("/yk02/login.do");
			return false;
		}
		else {
			System.out.println("Inteceptor : Session Check true");
			return super.preHandle(request, response, handler);
		}		
	}
}
